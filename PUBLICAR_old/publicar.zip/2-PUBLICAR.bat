@echo off
chcp 65001 >nul
title fonteboa — publicando...

:: Pasta do site (onde estão os HTMLs e o repositório Git)
:: Ajuste este caminho se necessário
set SITE_DIR=%~dp0site

:: Roda o publicador
node "%~dp0publicar.js" "%SITE_DIR%"

echo.
pause
