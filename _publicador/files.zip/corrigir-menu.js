/**
 * corrigir-menu.js — fonteboa
 * Substitui todas as referências a novelas/nouvelles
 * pelo termo correto crônicas em todos os HTMLs do site.
 */

const fs   = require('fs');
const path = require('path');

const siteDir = process.argv[2] || '.';

const substituicoes = [
  // href + label no nav
  [ 'href="novelas_index.html">novelas',     'href="cronicas_index.html">crônicas'     ],
  [ 'href="novelas_index.html">nouvelles',   'href="cronicas_index.html">crônicas'     ],
  [ 'href="novelas_index.html">índice de novelas',   'href="cronicas_index.html">índice de crônicas' ],
  [ 'href="novelas_index.html">índice de nouvelles', 'href="cronicas_index.html">índice de crônicas' ],
  [ 'href="nouvelles_index.html">nouvelles', 'href="cronicas_index.html">crônicas'     ],
  // class active
  [ 'class="active" href="novelas_index.html"',   'class="active" href="cronicas_index.html"'   ],
  [ 'class="active" href="nouvelles_index.html"', 'class="active" href="cronicas_index.html"'   ],
];

const arquivos = fs.readdirSync(siteDir)
  .filter(f => f.endsWith('.html'));

let totalCorrigidos = 0;

for (const arquivo of arquivos) {
  const caminho = path.join(siteDir, arquivo);
  let conteudo = fs.readFileSync(caminho, 'utf8');
  const original = conteudo;

  for (const [busca, troca] of substituicoes) {
    conteudo = conteudo.split(busca).join(troca);
  }

  if (conteudo !== original) {
    fs.writeFileSync(caminho, conteudo, 'utf8');
    console.log(`  ✓ corrigido: ${arquivo}`);
    totalCorrigidos++;
  }
}

if (totalCorrigidos === 0) {
  console.log('  Nenhum arquivo precisou de correção.');
} else {
  console.log(`\n  ${totalCorrigidos} arquivo(s) corrigido(s).`);
}
