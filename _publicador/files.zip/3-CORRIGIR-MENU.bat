@echo off
chcp 65001 >nul
title fonteboa — corrigindo referências novelas → crônicas

set SITE=C:\TEXTOS\SITE

echo.
echo ══════════════════════════════════════
echo   fonteboa — corrigindo menu
echo ══════════════════════════════════════
echo.

node "%~dp0corrigir-menu.js" "%SITE%"

echo.
pause
